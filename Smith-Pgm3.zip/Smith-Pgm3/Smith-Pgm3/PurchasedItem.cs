﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Smith_Pgm3
{
    internal class PurchasedItem
    {
        private int item;
        private int size;
        private int quantity;
        
        public PurchasedItem(int item, int size, int quantity)
        {
            //initializes the class 
            this.item = item;
            this.size = size;
            this.quantity = quantity;
        }
        private static decimal[,] itemCost; // 2-d array of item costs
        private static string format;

        static PurchasedItem()
        {
            format = "{0, 2} {1, 1} {2, -15} {3, 10:C}";
            itemCost = new decimal[4, 3]
            {
                {2.50M, 3.00M, 3.50M},
                {0.99M, 1.29M, 1.49M},
                {1.29M, 1.40M, 1.60M},
                {0.00M, 0.00M, 0.00M}
            };
        }
       public decimal cost
        {
            //gathers the cost from the itemCost array
            get
            {
                decimal unitCost = itemCost[item, size];
                return quantity * unitCost;
            }
        }
        public override string ToString()
        {
            //overrides ToString to make it work with the classes, also formats the whole thing to look nice
            string name = GetItemName(item);
            string itemSize = GetSize(size);
            return string.Format(format, quantity, itemSize, name, cost);
        }
        private string GetSize(int itemSize)
        {
            //uses a switchcase to convers the int itemSize to the corresponding string
            switch (itemSize)
            {
                case 0: return "S";
                case 1: return "M";
                case 2: return "L";
                default: return "N/a";
            }
        }
        private string GetItemName(int itemNumber)
        {
            //uses a switchcase to convert the int itemNumber to the corresponding string
            switch (itemNumber)
            {
                case 0: return "Burger";
                case 1: return "Fries";
                case 2: return "Soft Drink";
                case 3: return "Water";
                default: return "Unknown";
            }
        }
    }
}
