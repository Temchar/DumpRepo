﻿namespace Smith_Pgm3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.radBurger = new System.Windows.Forms.RadioButton();
            this.cboQuantity = new System.Windows.Forms.ComboBox();
            this.lbxOrder = new System.Windows.Forms.ListBox();
            this.btnPlace = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnOrder = new System.Windows.Forms.Button();
            this.lblTotalLabel = new System.Windows.Forms.Label();
            this.lblTotal = new System.Windows.Forms.Label();
            this.grpItem = new System.Windows.Forms.GroupBox();
            this.radWater = new System.Windows.Forms.RadioButton();
            this.radDrink = new System.Windows.Forms.RadioButton();
            this.radFries = new System.Windows.Forms.RadioButton();
            this.grpSize = new System.Windows.Forms.GroupBox();
            this.radLarge = new System.Windows.Forms.RadioButton();
            this.radMedium = new System.Windows.Forms.RadioButton();
            this.radSmall = new System.Windows.Forms.RadioButton();
            this.lblQuantity = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.grpItem.SuspendLayout();
            this.grpSize.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // radBurger
            // 
            this.radBurger.AccessibleName = "radBurger";
            this.radBurger.AutoSize = true;
            this.radBurger.Location = new System.Drawing.Point(7, 23);
            this.radBurger.Margin = new System.Windows.Forms.Padding(4);
            this.radBurger.Name = "radBurger";
            this.radBurger.Size = new System.Drawing.Size(69, 21);
            this.radBurger.TabIndex = 2;
            this.radBurger.TabStop = true;
            this.radBurger.Text = "Burger";
            this.radBurger.UseVisualStyleBackColor = true;
            this.radBurger.CheckedChanged += new System.EventHandler(this.radBurger_CheckedChanged);
            // 
            // cboQuantity
            // 
            this.cboQuantity.AccessibleName = "cboQuantity";
            this.cboQuantity.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboQuantity.FormattingEnabled = true;
            this.cboQuantity.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.cboQuantity.Location = new System.Drawing.Point(480, 49);
            this.cboQuantity.Margin = new System.Windows.Forms.Padding(4);
            this.cboQuantity.Name = "cboQuantity";
            this.cboQuantity.Size = new System.Drawing.Size(78, 24);
            this.cboQuantity.TabIndex = 3;
            // 
            // lbxOrder
            // 
            this.lbxOrder.AccessibleName = "lbxOrder";
            this.lbxOrder.Font = new System.Drawing.Font("Courier New", 10F);
            this.lbxOrder.FormattingEnabled = true;
            this.lbxOrder.ItemHeight = 16;
            this.lbxOrder.Location = new System.Drawing.Point(267, 225);
            this.lbxOrder.Margin = new System.Windows.Forms.Padding(4);
            this.lbxOrder.Name = "lbxOrder";
            this.lbxOrder.Size = new System.Drawing.Size(366, 180);
            this.lbxOrder.TabIndex = 4;
            this.lbxOrder.SelectedIndexChanged += new System.EventHandler(this.lbxOrder_SelectedIndexChanged);
            // 
            // btnPlace
            // 
            this.btnPlace.AccessibleName = "btnPlace";
            this.btnPlace.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btnPlace.Location = new System.Drawing.Point(493, 425);
            this.btnPlace.Margin = new System.Windows.Forms.Padding(4);
            this.btnPlace.Name = "btnPlace";
            this.btnPlace.Size = new System.Drawing.Size(140, 28);
            this.btnPlace.TabIndex = 5;
            this.btnPlace.Text = "Place Order";
            this.btnPlace.UseVisualStyleBackColor = true;
            this.btnPlace.Click += new System.EventHandler(this.btnPlace_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.AccessibleName = "btnDelete";
            this.btnDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btnDelete.Location = new System.Drawing.Point(267, 425);
            this.btnDelete.Margin = new System.Windows.Forms.Padding(4);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(140, 28);
            this.btnDelete.TabIndex = 6;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnOrder
            // 
            this.btnOrder.AccessibleName = "btnOrder";
            this.btnOrder.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btnOrder.Location = new System.Drawing.Point(480, 107);
            this.btnOrder.Margin = new System.Windows.Forms.Padding(4);
            this.btnOrder.Name = "btnOrder";
            this.btnOrder.Size = new System.Drawing.Size(153, 28);
            this.btnOrder.TabIndex = 7;
            this.btnOrder.Text = "Add to Order";
            this.btnOrder.UseVisualStyleBackColor = true;
            this.btnOrder.Click += new System.EventHandler(this.btnOrder_Click);
            // 
            // lblTotalLabel
            // 
            this.lblTotalLabel.AccessibleName = "lblTotalLabel";
            this.lblTotalLabel.AutoSize = true;
            this.lblTotalLabel.Location = new System.Drawing.Point(480, 166);
            this.lblTotalLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTotalLabel.Name = "lblTotalLabel";
            this.lblTotalLabel.Size = new System.Drawing.Size(81, 17);
            this.lblTotalLabel.TabIndex = 8;
            this.lblTotalLabel.Text = "Order Total";
            this.lblTotalLabel.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblTotal
            // 
            this.lblTotal.AccessibleName = "lblTotal";
            this.lblTotal.AutoSize = true;
            this.lblTotal.Location = new System.Drawing.Point(587, 166);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(44, 17);
            this.lblTotal.TabIndex = 9;
            this.lblTotal.Text = "$0.00";
            this.lblTotal.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // grpItem
            // 
            this.grpItem.AccessibleName = "grpItem";
            this.grpItem.Controls.Add(this.radWater);
            this.grpItem.Controls.Add(this.radDrink);
            this.grpItem.Controls.Add(this.radFries);
            this.grpItem.Controls.Add(this.radBurger);
            this.grpItem.Location = new System.Drawing.Point(12, 26);
            this.grpItem.Name = "grpItem";
            this.grpItem.Size = new System.Drawing.Size(200, 146);
            this.grpItem.TabIndex = 10;
            this.grpItem.TabStop = false;
            this.grpItem.Text = "Item";
            // 
            // radWater
            // 
            this.radWater.AccessibleName = "radWater";
            this.radWater.AutoSize = true;
            this.radWater.Location = new System.Drawing.Point(7, 110);
            this.radWater.Margin = new System.Windows.Forms.Padding(4);
            this.radWater.Name = "radWater";
            this.radWater.Size = new System.Drawing.Size(64, 21);
            this.radWater.TabIndex = 5;
            this.radWater.TabStop = true;
            this.radWater.Text = "Water";
            this.radWater.UseVisualStyleBackColor = true;
            this.radWater.CheckedChanged += new System.EventHandler(this.radWater_CheckedChanged);
            // 
            // radDrink
            // 
            this.radDrink.AccessibleName = "radDrink";
            this.radDrink.AutoSize = true;
            this.radDrink.Location = new System.Drawing.Point(7, 81);
            this.radDrink.Margin = new System.Windows.Forms.Padding(4);
            this.radDrink.Name = "radDrink";
            this.radDrink.Size = new System.Drawing.Size(88, 21);
            this.radDrink.TabIndex = 4;
            this.radDrink.TabStop = true;
            this.radDrink.Text = "Soft Drink";
            this.radDrink.UseVisualStyleBackColor = true;
            this.radDrink.CheckedChanged += new System.EventHandler(this.radDrink_CheckedChanged);
            // 
            // radFries
            // 
            this.radFries.AccessibleName = "radFries";
            this.radFries.AutoSize = true;
            this.radFries.Location = new System.Drawing.Point(7, 52);
            this.radFries.Margin = new System.Windows.Forms.Padding(4);
            this.radFries.Name = "radFries";
            this.radFries.Size = new System.Drawing.Size(57, 21);
            this.radFries.TabIndex = 3;
            this.radFries.TabStop = true;
            this.radFries.Text = "Fries";
            this.radFries.UseVisualStyleBackColor = true;
            this.radFries.CheckedChanged += new System.EventHandler(this.radFries_CheckedChanged);
            // 
            // grpSize
            // 
            this.grpSize.AccessibleName = "grpSize";
            this.grpSize.Controls.Add(this.radLarge);
            this.grpSize.Controls.Add(this.radMedium);
            this.grpSize.Controls.Add(this.radSmall);
            this.grpSize.Location = new System.Drawing.Point(233, 26);
            this.grpSize.Name = "grpSize";
            this.grpSize.Size = new System.Drawing.Size(200, 146);
            this.grpSize.TabIndex = 11;
            this.grpSize.TabStop = false;
            this.grpSize.Text = "Size";
            // 
            // radLarge
            // 
            this.radLarge.AccessibleName = "radLarge";
            this.radLarge.AutoSize = true;
            this.radLarge.Location = new System.Drawing.Point(7, 81);
            this.radLarge.Margin = new System.Windows.Forms.Padding(4);
            this.radLarge.Name = "radLarge";
            this.radLarge.Size = new System.Drawing.Size(63, 21);
            this.radLarge.TabIndex = 8;
            this.radLarge.TabStop = true;
            this.radLarge.Text = "Large";
            this.radLarge.UseVisualStyleBackColor = true;
            this.radLarge.CheckedChanged += new System.EventHandler(this.radLarge_CheckedChanged);
            // 
            // radMedium
            // 
            this.radMedium.AccessibleName = "radMedium";
            this.radMedium.AutoSize = true;
            this.radMedium.Location = new System.Drawing.Point(7, 52);
            this.radMedium.Margin = new System.Windows.Forms.Padding(4);
            this.radMedium.Name = "radMedium";
            this.radMedium.Size = new System.Drawing.Size(75, 21);
            this.radMedium.TabIndex = 7;
            this.radMedium.TabStop = true;
            this.radMedium.Text = "Medium";
            this.radMedium.UseVisualStyleBackColor = true;
            this.radMedium.CheckedChanged += new System.EventHandler(this.radMedium_CheckedChanged);
            // 
            // radSmall
            // 
            this.radSmall.AccessibleName = "radSmall";
            this.radSmall.AutoSize = true;
            this.radSmall.Location = new System.Drawing.Point(7, 23);
            this.radSmall.Margin = new System.Windows.Forms.Padding(4);
            this.radSmall.Name = "radSmall";
            this.radSmall.Size = new System.Drawing.Size(60, 21);
            this.radSmall.TabIndex = 6;
            this.radSmall.TabStop = true;
            this.radSmall.Text = "Small";
            this.radSmall.UseVisualStyleBackColor = true;
            this.radSmall.CheckedChanged += new System.EventHandler(this.radSmall_CheckedChanged);
            // 
            // lblQuantity
            // 
            this.lblQuantity.AccessibleName = "lblQuantity";
            this.lblQuantity.AutoSize = true;
            this.lblQuantity.Location = new System.Drawing.Point(480, 26);
            this.lblQuantity.Name = "lblQuantity";
            this.lblQuantity.Size = new System.Drawing.Size(61, 17);
            this.lblQuantity.TabIndex = 12;
            this.lblQuantity.Text = "Quantity";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Smith_Pgm3.Properties.Resources.burger;
            this.pictureBox1.Location = new System.Drawing.Point(19, 225);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(215, 180);
            this.pictureBox1.TabIndex = 13;
            this.pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(649, 477);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.lblQuantity);
            this.Controls.Add(this.grpSize);
            this.Controls.Add(this.grpItem);
            this.Controls.Add(this.lblTotal);
            this.Controls.Add(this.lblTotalLabel);
            this.Controls.Add(this.btnOrder);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnPlace);
            this.Controls.Add(this.lbxOrder);
            this.Controls.Add(this.cboQuantity);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "Burger Place";
            this.grpItem.ResumeLayout(false);
            this.grpItem.PerformLayout();
            this.grpSize.ResumeLayout(false);
            this.grpSize.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RadioButton radBurger;
        private System.Windows.Forms.ComboBox cboQuantity;
        private System.Windows.Forms.ListBox lbxOrder;
        private System.Windows.Forms.Button btnPlace;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnOrder;
        private System.Windows.Forms.Label lblTotalLabel;
        private System.Windows.Forms.Label lblTotal;
        private System.Windows.Forms.GroupBox grpItem;
        private System.Windows.Forms.RadioButton radWater;
        private System.Windows.Forms.RadioButton radDrink;
        private System.Windows.Forms.RadioButton radFries;
        private System.Windows.Forms.GroupBox grpSize;
        private System.Windows.Forms.RadioButton radLarge;
        private System.Windows.Forms.RadioButton radMedium;
        private System.Windows.Forms.RadioButton radSmall;
        private System.Windows.Forms.Label lblQuantity;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

