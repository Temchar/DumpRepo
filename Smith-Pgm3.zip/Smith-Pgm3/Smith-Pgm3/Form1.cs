﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Smith_Pgm3
{
    public partial class Form1 : Form
    {
        private int formItem;
        private int formSize;
        private decimal totalCharge = 0;
        private int quantity;
        
        public Form1()
        {
            //initializes the form and disables things that should start disabled
            InitializeComponent();
            btnDelete.Enabled = false;
            radLarge.Enabled = false;
            radMedium.Enabled = false;
            radSmall.Enabled = false;
            cboQuantity.Enabled = false;
        }

        private void UpdateTotalLabel()
        { //helper function to update lblTotal
            
            totalCharge = 0;
            foreach (PurchasedItem item in lbxOrder.Items)
            {
                totalCharge += item.cost;
            }
            lblTotal.Text = $" {totalCharge:C}";
        }

        private void enableSizes() {
            //helper function to enable sizes as needed
            radLarge.Enabled = true;
            radMedium.Enabled = true;
            radSmall.Enabled = true;
        }
        private void Disabler()
        {
            //helper function to disable things when an item has been added
            radLarge.Enabled = false;
            radMedium.Enabled = false;
            radSmall.Enabled = false;
            cboQuantity.Enabled = false;
        }

        private void radBurger_CheckedChanged(object sender, EventArgs e)
        {
            //event function for Burger radio
            enableSizes();
            cboQuantity.Enabled = false;
            btnOrder.Enabled = false;
            formItem = 0;
            
        }

        private void radFries_CheckedChanged(object sender, EventArgs e)
        {
            //event Function for Fried radio
            enableSizes();
            cboQuantity.Enabled = false;
            btnOrder.Enabled = false;
            formItem = 1;
        }

        private void radDrink_CheckedChanged(object sender, EventArgs e)
        {
            //event Function for SoftDrink radio
            enableSizes();
            cboQuantity.Enabled = false;
            btnOrder.Enabled = false;
            formItem = 2;
        }

        private void radWater_CheckedChanged(object sender, EventArgs e)
        {
            //event Function for Water radio, also turns off medium and large radio
            radSmall.Enabled = true;
            radSmall.Select();
            radLarge.Enabled = false;
            radMedium.Enabled= false;
            cboQuantity.Enabled = true;
            btnOrder.Enabled = true;
            formItem = 3;
            formSize = 0;
            this.cboQuantity.SelectedIndex = 0;
        }

        private void radSmall_CheckedChanged(object sender, EventArgs e)
        {
            //event Function for Small radio
            cboQuantity.Enabled = true;
            btnOrder.Enabled = true;
            this.cboQuantity.SelectedIndex = 0;
            formSize = 0;
        }

        private void radMedium_CheckedChanged(object sender, EventArgs e)
        {
            //event Function for Medium radio
            cboQuantity.Enabled = true;
            btnOrder.Enabled = true;
            this.cboQuantity.SelectedIndex = 0;
            formSize = 1;
        }

        private void radLarge_CheckedChanged(object sender, EventArgs e)
        {
            //event Function for Large radio
            cboQuantity.Enabled = true;
            btnOrder.Enabled = true;
            this.cboQuantity.SelectedIndex = 0;
            formSize = 2;
        }

        private void btnOrder_Click(object sender, EventArgs e)
        {
            //Event Function for Order Button. uses a switchcase to assign proper quantity, then creates a new PurchasedItem class and adds it to the Order ListBox. calls UpdateTotalLabel
            switch (cboQuantity.SelectedItem) {
                case "1":
                    quantity = 1;
                    break;
                case "2":
                    quantity = 2;
                    break;
                case "3":
                    quantity = 3;
                    break;
                case "4":
                    quantity = 4;
                    break;
                case "5":
                    quantity = 5;
                    break;
                case "6":
                    quantity = 6;
                    break;
                case "7":
                    quantity = 7;
                    break;
                case "8":
                    quantity = 8;
                    break;
                case "9":
                    quantity = 9;
                    break;
                case "10":
                    quantity = 10;
                    break;
            }
            PurchasedItem newItem = new PurchasedItem(formItem,formSize, quantity );
            lbxOrder.Items.Add(newItem);
            UpdateTotalLabel();
            Disabler();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            //Event Function for Delete Button. checks if an index is selected, then if one is it removes it and calls UpdateTotalLabel. also turns itself back off afterwards
            int selectedIndex = lbxOrder.SelectedIndex;       
            if (selectedIndex != -1)
            {
                lbxOrder.Items.RemoveAt(selectedIndex);
                UpdateTotalLabel();
                btnDelete.Enabled = false;
            }
        }

        private void btnPlace_Click(object sender, EventArgs e)
        {
            //Event Function for Place Order Button. it just closes the window
            Close();
        }

        private void lbxOrder_SelectedIndexChanged(object sender, EventArgs e)
        {
            //Enables the Delete button if an index is selected
            btnDelete.Enabled = true;
        }
    }

}
