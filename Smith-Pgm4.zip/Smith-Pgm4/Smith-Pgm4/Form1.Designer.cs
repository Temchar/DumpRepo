﻿namespace Smith_Pgm4
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbxEvents = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtEventDetail = new System.Windows.Forms.TextBox();
            this.TxtTime = new System.Windows.Forms.TextBox();
            this.txtDate = new System.Windows.Forms.TextBox();
            this.TxtDay = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.Date = new System.Windows.Forms.Label();
            this.Day = new System.Windows.Forms.Label();
            this.Time = new System.Windows.Forms.Label();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnNew = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbxEvents
            // 
            this.lbxEvents.FormattingEnabled = true;
            this.lbxEvents.ItemHeight = 16;
            this.lbxEvents.Location = new System.Drawing.Point(16, 36);
            this.lbxEvents.Margin = new System.Windows.Forms.Padding(4);
            this.lbxEvents.Name = "lbxEvents";
            this.lbxEvents.Size = new System.Drawing.Size(244, 180);
            this.lbxEvents.TabIndex = 0;
            this.lbxEvents.SelectedIndexChanged += new System.EventHandler(this.Events_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 16);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(51, 17);
            this.label1.TabIndex = 1;
            this.label1.Text = "Events";
            // 
            // txtEventDetail
            // 
            this.txtEventDetail.AccessibleName = "txtEventDetail";
            this.txtEventDetail.Location = new System.Drawing.Point(347, 36);
            this.txtEventDetail.Margin = new System.Windows.Forms.Padding(4);
            this.txtEventDetail.Name = "txtEventDetail";
            this.txtEventDetail.Size = new System.Drawing.Size(207, 23);
            this.txtEventDetail.TabIndex = 2;
            // 
            // TxtTime
            // 
            this.TxtTime.AccessibleName = "TxtTime";
            this.TxtTime.Location = new System.Drawing.Point(421, 133);
            this.TxtTime.Margin = new System.Windows.Forms.Padding(4);
            this.TxtTime.Name = "TxtTime";
            this.TxtTime.Size = new System.Drawing.Size(132, 23);
            this.TxtTime.TabIndex = 3;
            // 
            // txtDate
            // 
            this.txtDate.AccessibleName = "TxtDate";
            this.txtDate.Location = new System.Drawing.Point(421, 69);
            this.txtDate.Margin = new System.Windows.Forms.Padding(4);
            this.txtDate.Name = "txtDate";
            this.txtDate.Size = new System.Drawing.Size(132, 23);
            this.txtDate.TabIndex = 4;
            // 
            // TxtDay
            // 
            this.TxtDay.AccessibleName = "TxtDay";
            this.TxtDay.Location = new System.Drawing.Point(421, 101);
            this.TxtDay.Margin = new System.Windows.Forms.Padding(4);
            this.TxtDay.Name = "TxtDay";
            this.TxtDay.Size = new System.Drawing.Size(132, 23);
            this.TxtDay.TabIndex = 5;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(343, 16);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(84, 17);
            this.label2.TabIndex = 6;
            this.label2.Text = "Event Detail";
            // 
            // Date
            // 
            this.Date.AutoSize = true;
            this.Date.Location = new System.Drawing.Point(343, 69);
            this.Date.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Date.Name = "Date";
            this.Date.Size = new System.Drawing.Size(38, 17);
            this.Date.TabIndex = 7;
            this.Date.Text = "Date";
            // 
            // Day
            // 
            this.Day.AutoSize = true;
            this.Day.Location = new System.Drawing.Point(344, 101);
            this.Day.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Day.Name = "Day";
            this.Day.Size = new System.Drawing.Size(33, 17);
            this.Day.TabIndex = 8;
            this.Day.Text = "Day";
            // 
            // Time
            // 
            this.Time.AutoSize = true;
            this.Time.Location = new System.Drawing.Point(344, 133);
            this.Time.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Time.Name = "Time";
            this.Time.Size = new System.Drawing.Size(39, 17);
            this.Time.TabIndex = 9;
            this.Time.Text = "Time";
            // 
            // btnDelete
            // 
            this.btnDelete.AccessibleName = "btnDelete";
            this.btnDelete.Enabled = false;
            this.btnDelete.Location = new System.Drawing.Point(345, 191);
            this.btnDelete.Margin = new System.Windows.Forms.Padding(4);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(100, 28);
            this.btnDelete.TabIndex = 10;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDeleteClick);
            // 
            // btnNew
            // 
            this.btnNew.AccessibleName = "btnNew";
            this.btnNew.Location = new System.Drawing.Point(455, 191);
            this.btnNew.Margin = new System.Windows.Forms.Padding(4);
            this.btnNew.Name = "btnNew";
            this.btnNew.Size = new System.Drawing.Size(100, 28);
            this.btnNew.TabIndex = 11;
            this.btnNew.Text = "New";
            this.btnNew.UseVisualStyleBackColor = true;
            this.btnNew.Click += new System.EventHandler(this.btnNewClick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(580, 252);
            this.Controls.Add(this.btnNew);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.Time);
            this.Controls.Add(this.Day);
            this.Controls.Add(this.Date);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.TxtDay);
            this.Controls.Add(this.txtDate);
            this.Controls.Add(this.TxtTime);
            this.Controls.Add(this.txtEventDetail);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lbxEvents);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "Personal Calendar";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Click += new System.EventHandler(this.newBtnClick);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox lbxEvents;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtEventDetail;
        private System.Windows.Forms.TextBox TxtTime;
        private System.Windows.Forms.TextBox txtDate;
        private System.Windows.Forms.TextBox TxtDay;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label Date;
        private System.Windows.Forms.Label Day;
        private System.Windows.Forms.Label Time;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnNew;
    }
}

