﻿namespace Smith_Pgm4
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.monthCalendar = new System.Windows.Forms.MonthCalendar();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtDescription = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.cboStartHour = new System.Windows.Forms.ComboBox();
            this.cboStartMin = new System.Windows.Forms.ComboBox();
            this.cboEndHour = new System.Windows.Forms.ComboBox();
            this.cboEndMin = new System.Windows.Forms.ComboBox();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // monthCalendar
            // 
            this.monthCalendar.Location = new System.Drawing.Point(21, 20);
            this.monthCalendar.Margin = new System.Windows.Forms.Padding(12, 11, 12, 11);
            this.monthCalendar.Name = "monthCalendar";
            this.monthCalendar.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(270, 20);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(73, 17);
            this.label1.TabIndex = 1;
            this.label1.Text = "Start Time";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(270, 102);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(72, 17);
            this.label2.TabIndex = 2;
            this.label2.Text = "Stop Time";
            // 
            // txtDescription
            // 
            this.txtDescription.Location = new System.Drawing.Point(21, 214);
            this.txtDescription.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtDescription.Name = "txtDescription";
            this.txtDescription.Size = new System.Drawing.Size(499, 23);
            this.txtDescription.TabIndex = 3;
            this.txtDescription.TextChanged += new System.EventHandler(this.txtDescription_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(18, 193);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(119, 17);
            this.label3.TabIndex = 4;
            this.label3.Text = "Event Description";
            // 
            // cboStartHour
            // 
            this.cboStartHour.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboStartHour.FormattingEnabled = true;
            this.cboStartHour.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20",
            "21",
            "22",
            "23"});
            this.cboStartHour.Location = new System.Drawing.Point(274, 40);
            this.cboStartHour.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cboStartHour.Name = "cboStartHour";
            this.cboStartHour.Size = new System.Drawing.Size(109, 24);
            this.cboStartHour.TabIndex = 5;
            // 
            // cboStartMin
            // 
            this.cboStartMin.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboStartMin.FormattingEnabled = true;
            this.cboStartMin.Items.AddRange(new object[] {
            "00",
            "15",
            "30",
            "45"});
            this.cboStartMin.Location = new System.Drawing.Point(411, 40);
            this.cboStartMin.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cboStartMin.Name = "cboStartMin";
            this.cboStartMin.Size = new System.Drawing.Size(109, 24);
            this.cboStartMin.TabIndex = 6;
            // 
            // cboEndHour
            // 
            this.cboEndHour.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboEndHour.FormattingEnabled = true;
            this.cboEndHour.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20",
            "21",
            "22",
            "23"});
            this.cboEndHour.Location = new System.Drawing.Point(274, 121);
            this.cboEndHour.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cboEndHour.Name = "cboEndHour";
            this.cboEndHour.Size = new System.Drawing.Size(109, 24);
            this.cboEndHour.TabIndex = 7;
            // 
            // cboEndMin
            // 
            this.cboEndMin.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboEndMin.FormattingEnabled = true;
            this.cboEndMin.Items.AddRange(new object[] {
            "00",
            "15",
            "30",
            "45"});
            this.cboEndMin.Location = new System.Drawing.Point(411, 121);
            this.cboEndMin.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cboEndMin.Name = "cboEndMin";
            this.cboEndMin.Size = new System.Drawing.Size(109, 24);
            this.cboEndMin.TabIndex = 8;
            // 
            // btnCancel
            // 
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.Location = new System.Drawing.Point(21, 244);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 9;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnAdd.Location = new System.Drawing.Point(445, 244);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(75, 23);
            this.btnAdd.TabIndex = 10;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // Form2
            // 
            this.AcceptButton = this.btnAdd;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnCancel;
            this.ClientSize = new System.Drawing.Size(543, 288);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.cboEndMin);
            this.Controls.Add(this.cboEndHour);
            this.Controls.Add(this.cboStartMin);
            this.Controls.Add(this.cboStartHour);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtDescription);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.monthCalendar);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Form2";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MonthCalendar monthCalendar;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtDescription;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cboStartHour;
        private System.Windows.Forms.ComboBox cboStartMin;
        private System.Windows.Forms.ComboBox cboEndHour;
        private System.Windows.Forms.ComboBox cboEndMin;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnAdd;
    }
}