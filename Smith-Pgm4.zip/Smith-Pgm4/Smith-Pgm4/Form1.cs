﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Smith_Pgm4
{
    public partial class Form1 : Form
    {
        
        public Form1()
        {
            InitializeComponent();
            Disabler();
        }
        private void Disabler()
        {
            txtDate.Enabled = false;
            TxtDay.Enabled = false;
            TxtTime.Enabled = false;
            txtEventDetail.Enabled = false;
            btnDelete.Enabled = false;
        }
        private void newBtnClick(object sender, EventArgs e)
        {

        }

        private void btnNewClick(object sender, EventArgs e)
        {
           Form2 frm = new Form2();
            frm.ShowDialog();
        }

        private void btnDeleteClick(object sender, EventArgs e)
        {
            //Event Function for Delete Button. checks if an index is selected, then if one is it removes it and calls UpdateTotalLabel. also turns itself back off afterwards
            int selectedIndex = lbxEvents.SelectedIndex;
            if (selectedIndex != -1)
            {
                lbxEvents.Items.RemoveAt(selectedIndex);
                txtEventDetail.Clear();
                txtDate.Clear();
                TxtDay.Clear();
                TxtTime.Clear();
                btnDelete.Enabled = false;

            }
        }

        private void txtDetailChange(object sender, EventArgs e)
        {
            
        }

        private void txtDateChange(object sender, EventArgs e)
        {
            
        }

        private void txtDayChange(object sender, EventArgs e)
        {
            
        }

        private void txtTimeChange(object sender, EventArgs e)
        {
            
        }

        private void Events_SelectedIndexChanged(object sender, EventArgs e)
        {
            Event newEvent = (Event)lbxEvents.SelectedItem;
            btnDelete.Enabled = true;
            txtEventDetail.Clear();
            txtDate.Clear();
            TxtDay.Clear();
            TxtTime.Clear();
            txtEventDetail.AppendText(newEvent.title);
            txtDate.AppendText(newEvent.start.Date.ToString());
            TxtDay.AppendText(newEvent.start.DayOfWeek.ToString());
            TxtTime.AppendText(newEvent.start.TimeOfDay.ToString() + " to " + newEvent.end.TimeOfDay.ToString());
            
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            Form2.MainLbx = lbxEvents;
        }
    }
}
