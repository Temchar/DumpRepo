﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Metadata.W3cXsd2001;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Smith_Pgm4
{
    
public partial class Form2 : Form
    {
        int month;
        int day;
        int year;
        int startHour;
        int endHour;
        int startMinute;
        string title;
        private Event newEvent;
        public Event NewEvent
        {
            get { return newEvent; }
        }
        private static ListBox mainLbx;
        public static ListBox MainLbx
        {
            get { return mainLbx; }
            set { mainLbx = value; }
        }
        public Form2()
        {
            InitializeComponent();
        }

        private void txtDescription_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form2_Load(object sender, EventArgs e)
        {
            DateTime eoy = DateTime.Parse(DateTime.Today.Year + "/12/31");
            monthCalendar.MinDate = DateTime.Today;
            monthCalendar.MaxDate = eoy;
            
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            month = monthCalendar.SelectionStart.Month;
            day = monthCalendar.SelectionStart.Day;
            year = monthCalendar.SelectionStart.Year;
            switch (cboStartHour.SelectedItem)
            {
                case "0":
                    startHour = 0;
                    break;
                case "1":
                    startHour = 1;
                    break;
                case "2":
                    startHour = 2;
                    break;
                case "3":
                    startHour = 3;
                    break;
                case "4":
                    startHour = 4;
                    break;
                case "5":
                    startHour = 5;
                    break;
                case "6":
                    startHour = 6;
                    break;
                case "7":
                    startHour = 7;
                    break;
                case "8":
                    startHour= 8;
                    break;
                case "9":
                    startHour =9;
                    break;
                case "10":
                    startHour = 10;
                    break;
                case "11":
                    startHour = 11;
                    break;
                case "12":
                    startHour = 12;
                    break;
                case "13":
                    startHour = 13;
                    break;
                case "14":
                    startHour = 14;
                    break;
                case "15":
                    startHour = 15;
                    break;
                case "16":
                    startHour = 16;
                    break;
                case "17":
                    startHour = 17;
                    break;
                case "18":
                    startHour = 18;
                    break;
                case "19":
                    startHour = 19;
                    break;
                case "20":
                    startHour = 20;
                    break;
                case "21":
                    startHour = 21;
                    break;
                case "22":
                    startHour = 22;
                    break;
                case "23":
                    startHour = 23;
                    break;
                default:
                    startHour = 0;
                    break;

            }
            switch (cboEndHour.SelectedItem)
            {
                case "0":
                    endHour = 0;
                    break;
                case "1":
                    endHour = 1;
                    break;
                case "2":
                    endHour = 2;
                    break;
                case "3":
                    endHour = 3;
                    break;
                case "4":
                    endHour = 4;
                    break;
                case "5":
                    endHour = 5;
                    break;
                case "6":
                    endHour = 6;
                    break;
                case "7":
                    endHour = 7;
                    break;
                case "8":
                    endHour = 8;
                    break;
                case "9":
                    endHour = 9;
                    break;
                case "10":
                    endHour = 10;
                    break;
                case "11":
                    endHour = 11;
                    break;
                case "12":
                    endHour = 12;
                    break;
                case "13":
                    endHour = 13;
                    break;
                case "14":
                    endHour = 14;
                    break;
                case "15":
                    endHour = 15;
                    break;
                case "16":
                    endHour = 16;
                    break;
                case "17":
                    endHour = 17;
                    break;
                case "18":
                    endHour = 18;
                    break;
                case "19":
                    endHour = 19;
                    break;
                case "20":
                    endHour = 20;
                    break;
                case "21":
                    endHour = 21;
                    break;
                case "22":
                    endHour = 22;
                    break;
                case "23":
                    endHour = 23;
                    break;
                default:
                    endHour = 0;
                    break;


            }
            switch (cboStartMin.SelectedItem)
            {
                case "00":
                    startMinute = 00;
                    break;
                case "15":
                    startMinute = 15;
                    break;
                case "30":
                    startMinute = 30;
                    break;
                case "45":
                    startMinute = 45;
                    break;
                default:
                    startMinute = 0;
                    break;
            }
            string title = txtDescription.Text.ToString();
            
            try
            {
               
                newEvent = new Event(month, day, year, startHour, endHour, startMinute, title);
                this.Close();
            }
            catch(Exception exception)
            {
                MessageBox.Show(exception + " cannot be empty.");
            }
            foreach (Event otherEvent in mainLbx.Items)
            {
                if (string.IsNullOrEmpty(title))
                {
                    throw new ArgumentException("Event Description needed");
                }
                else if (otherEvent.Equals(newEvent))
                {
                    MessageBox.Show("New Event conflicts with an existing Event");
                    throw new ArgumentException("New Event conflicts with an existing Event");
                }
                
            }
            MainLbx.Items.Add(newEvent);
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
