﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Smith_Pgm4
{
    public class Event
    {
        private int month;
        private int day;
        private int year;
        private int startHour;
        private int endHour;
        private int startMinute;
        public string title;

        public Event(int month, int day, int year, int startHour, int endHour, int startMinute, string title)
        {
            if (title == string.Empty)
            {
                MessageBox.Show("Event start hour cannot be before end hour");
                throw new ArgumentException("Event must have a title");
            }
            if (startHour >= endHour)
            {
                MessageBox.Show("Event start hour cannot be before end hour");
                throw new ArgumentException("Event start hour cannot be before end hour");
            }
            this.month = month;
            this.day = day;
            this.year = year;
            this.startHour = startHour;
            this.endHour = endHour;
            this.startMinute = startMinute;
            this.title = title;

        }
        public DateTime start
        {
            get { return new DateTime(year, month, day, startHour, startMinute, 0); }
        }
        public DateTime end
        {
            get { return new DateTime(year, month, day, endHour, 0, 0); }
        }
        public override bool Equals(object obj)
        {
            if (obj == null || !(obj is Event))
            {
                return false;
            }

            Event other = (Event)obj;
            return (start==other.start && end==other.end && title==other.title);
        }
        public override int GetHashCode()
        {
            return start.GetHashCode() ^ end.GetHashCode() ^ title.GetHashCode();
        }

        public override string ToString()
        {
            return $"{start.Year}-{start.Month:D2}-{start.Day:D2} {start.Hour:D2}:{start.Minute:D2}";
        }
        public string GetTitle() { return title; }
        public void SetTitle(string title) { this.title = title; }
        
    }
}
