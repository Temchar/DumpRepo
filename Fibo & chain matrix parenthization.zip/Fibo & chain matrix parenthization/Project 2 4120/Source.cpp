#include <vector>
#include <iostream>
#include <fstream>
#include <chrono>  
#include <climits> 

using namespace std;


int matrixRecursive(const vector<int>& dims, int i, int j) {
    if (i == j) return 0;

    int minCost = INT_MAX;

    for (int k = i; k < j; ++k) {
        int cost = matrixRecursive(dims, i, k) + matrixRecursive(dims, k + 1, j) + dims[i - 1] * dims[k] * dims[j];
        minCost = min(minCost, cost);
    }

    return minCost;
}

int matrixTopDown(const vector<int>& dims, int i, int j, vector<vector<int>>& memo) {
    if (i == j) return 0;

    if (memo[i][j] != -1) return memo[i][j];

    int minCost = INT_MAX;
    for (int k = i; k < j; ++k) {
        int cost = matrixTopDown(dims, i, k, memo) + matrixTopDown(dims, k + 1, j, memo) + dims[i - 1] * dims[k] * dims[j];
        minCost = min(minCost, cost);
    }

    return memo[i][j] = minCost;
}


int matrixBottomUp(const vector<int>& dims) {
    int n = dims.size();
    vector<vector<int>> dp(n, vector<int>(n, 0));

    for (int len = 2; len < n; ++len) {
        for (int i = 1; i < n - len + 1; ++i) {
            int j = i + len - 1;
            dp[i][j] = INT_MAX;
            for (int k = i; k < j; ++k) {
                int q = dp[i][k] + dp[k + 1][j] + dims[i - 1] * dims[k] * dims[j];
                dp[i][j] = min(dp[i][j], q);
            }
        }
    }

    return dp[1][n - 1];
}

int nmain() {
    ifstream inputFile("inputMatrix.txt"); 
    ofstream outputFile("MatrixChainOutput.txt");
    if (!inputFile.is_open()) {
        cerr << "Error: Could not open input file!" << endl;
        return 1;
    }

    int n;
    while (inputFile >> n) {
     
        vector<int> dims(n + 1);
        for (int i = 0; i <= n; ++i) {
            inputFile >> dims[i];
        }


        auto start = chrono::high_resolution_clock::now();
        matrixRecursive(dims, 1, n);
        auto end = chrono::high_resolution_clock::now();
        auto duration = chrono::duration_cast<chrono::microseconds>(end - start);
        outputFile << "Matrix Chain Recursive for n=" << n << ": " << duration.count() << " microseconds\n";

      
        vector<vector<int>> memo(n + 1, vector<int>(n + 1, -1));
        start = chrono::high_resolution_clock::now();
        matrixTopDown(dims, 1, n, memo);
        end = chrono::high_resolution_clock::now();
        duration = chrono::duration_cast<chrono::microseconds>(end - start);
        outputFile << "Matrix Chain Top-Down for n=" << n << ": " << duration.count() << " microseconds\n";

      
        start = chrono::high_resolution_clock::now();
        matrixBottomUp(dims);
        end = chrono::high_resolution_clock::now();
        duration = chrono::duration_cast<chrono::microseconds>(end - start);
        outputFile << "Matrix Chain Bottom-Up for n=" << n << ": " << duration.count() << " microseconds\n";


    }

    inputFile.close();
    outputFile.close();

    return 0;
}
