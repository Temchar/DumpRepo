#include <vector>
#include <iostream>
#include <fstream>
#include <chrono> 
using namespace std;
vector<int> memo;
int fibo(int n) {
 
    if (n <= 1) return n;

    return fibo(n - 1) + fibo(n - 2);

}
int fiboTopDown(int n) {
    if (n <= 1) return n;

    if (memo[n] != -1) return memo[n];

    memo[n] = fiboTopDown(n - 1) + fiboTopDown(n - 2);
    
    return memo[n];
}
vector<int> fiboBottomUp(int n) {
    if (n == 0) return {};

    if (n == 1) return { 0 };

    vector<int> fibo(n);

    fibo[0] = 0;

    fibo[1] = 1;

    for (int i = 2; i < n; i++) {
        fibo[i] = fibo[i - 1] + fibo[i - 2];
    }

    return fibo;
}
int main() {
    
    ifstream inputFile("inputFibo.txt"); 
    ofstream outputFile("FiboOutput.txt");
    if (!inputFile.is_open()) {
        cerr << "Error: Could not open input file!" << endl;
        return 1;
    }
    int n;
    while (inputFile >> n) {
 
        memo.resize(n + 1, -1);
        
        
        auto start = chrono::high_resolution_clock::now();
        fibo(n);  
        auto end = chrono::high_resolution_clock::now();
        auto duration = chrono::duration_cast<chrono::microseconds>(end - start);
        outputFile << "Fibo(" << n << ") Recursive: " << duration.count() << " microseconds\n";
        
       
        start = chrono::high_resolution_clock::now();
        fiboTopDown(n); 
        end = chrono::high_resolution_clock::now();
        duration = chrono::duration_cast<chrono::microseconds>(end - start);
        outputFile << "Fibo(" << n << ") memoized Top-Down: " << duration.count() << " microseconds\n";

        // Time the bottom-up Fibonacci
        start = chrono::high_resolution_clock::now();
        fiboBottomUp(n); 
        end = chrono::high_resolution_clock::now();
        duration = chrono::duration_cast<chrono::microseconds>(end - start);
        outputFile << "Fibo(" << n << ") Bottom-Up: " << duration.count() << " microseconds\n";

        outputFile << "-----------------------------------------\n";
    }

    inputFile.close();
    outputFile.close();

    return 0;
}